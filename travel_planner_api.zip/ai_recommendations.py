import os
import json
from datetime import timedelta
from anthropic import Anthropic

from database import Trip
from schemas import ItineraryResponse, ItineraryDayPlan

# The Anthropic API key is read from the environment variable ANTHROPIC_API_KEY.
# Set it before running the server, e.g.:
#   export ANTHROPIC_API_KEY="sk-ant-..."
client = Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY"))

MODEL = "claude-sonnet-4-6"


def generate_itinerary(trip: Trip, preferences: str | None) -> ItineraryResponse:
    """Calls Claude to generate a day-by-day itinerary for a trip."""

    num_days = (trip.end_date - trip.start_date).days + 1
    if num_days < 1:
        num_days = 1

    existing_items = ""
    if trip.items:
        lines = [f"- {item.title} ({item.category or 'activity'})" for item in trip.items]
        existing_items = "Already planned items to take into account:\n" + "\n".join(lines)

    prompt = f"""You are a travel planning assistant. Create a day-by-day itinerary.

Destination: {trip.destination}
Trip length: {num_days} day(s)
Start date: {trip.start_date.isoformat()}
End date: {trip.end_date.isoformat()}
Traveler preferences: {preferences or "No specific preferences given, suggest a well-rounded mix."}
{existing_items}

Respond with ONLY valid JSON (no markdown fences, no commentary) matching exactly this structure:
{{
  "days": [
    {{
      "day": 1,
      "summary": "short theme of the day",
      "activities": ["activity 1", "activity 2", "activity 3"]
    }}
  ]
}}

Provide exactly {num_days} day entries, numbered 1 through {num_days}, each with 3-5 concrete activities."""

    response = client.messages.create(
        model=MODEL,
        max_tokens=2000,
        messages=[{"role": "user", "content": prompt}],
    )

    raw_text = "".join(block.text for block in response.content if block.type == "text").strip()

    # Strip markdown code fences if the model added them despite instructions
    if raw_text.startswith("```"):
        raw_text = raw_text.strip("`")
        if raw_text.startswith("json"):
            raw_text = raw_text[4:].strip()

    try:
        parsed = json.loads(raw_text)
    except json.JSONDecodeError as e:
        raise ValueError(f"AI response was not valid JSON: {e}\nRaw response: {raw_text[:500]}")

    days = []
    for day_data in parsed.get("days", []):
        day_num = day_data.get("day", 1)
        day_date = trip.start_date + timedelta(days=day_num - 1)
        days.append(
            ItineraryDayPlan(
                day=day_num,
                date=day_date,
                summary=day_data.get("summary", ""),
                activities=day_data.get("activities", []),
            )
        )

    return ItineraryResponse(trip_id=trip.id, destination=trip.destination, days=days)
