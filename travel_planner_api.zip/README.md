# Travel Planner API

A REST API for planning trips, built with FastAPI + SQLite, with an AI-powered
day-by-day itinerary generator using the Claude API.

## Features

- Create, read, update, delete **trips** (name, destination, dates, notes)
- Create, read, update, delete **items** within a trip (flights, hotels,
  activities — with date, time, location, notes)
- **AI itinerary generation**: ask Claude to build a full day-by-day plan for
  a trip, optionally factoring in your preferences and anything you've
  already added to the trip

## Setup

1. Install dependencies:
   ```bash
   pip install fastapi uvicorn sqlalchemy anthropic pydantic
   ```

2. Set your Anthropic API key as an environment variable (required only for
   the AI itinerary endpoint — everything else works without it):
   ```bash
   export ANTHROPIC_API_KEY="sk-ant-..."
   ```

3. Run the server:
   ```bash
   uvicorn main:app --reload
   ```

4. Open your browser to **http://127.0.0.1:8000/docs** for interactive API
   docs (Swagger UI) where you can try every endpoint directly.

A SQLite database file (`travel_planner.db`) is created automatically in the
project folder the first time you run it. Delete that file any time to reset
all data.

## Endpoints

### Trips
| Method | Path                | Description           |
|--------|---------------------|------------------------|
| POST   | `/trips`             | Create a trip          |
| GET    | `/trips`             | List all trips         |
| GET    | `/trips/{id}`         | Get one trip + its items |
| PUT    | `/trips/{id}`         | Update a trip          |
| DELETE | `/trips/{id}`         | Delete a trip           |

### Items
| Method | Path                      | Description          |
|--------|---------------------------|------------------------|
| POST   | `/trips/{id}/items`        | Add an item to a trip |
| GET    | `/trips/{id}/items`        | List items for a trip |
| PUT    | `/items/{id}`               | Update an item         |
| DELETE | `/items/{id}`               | Delete an item          |

### AI Recommendations
| Method | Path                          | Description                          |
|--------|--------------------------------|----------------------------------------|
| POST   | `/trips/{id}/ai-itinerary`     | Generate a day-by-day AI itinerary    |

## Example: create a trip and get an AI itinerary

```bash
# 1. Create a trip
curl -X POST http://127.0.0.1:8000/trips \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Tokyo Trip",
    "destination": "Tokyo, Japan",
    "start_date": "2026-09-01",
    "end_date": "2026-09-03"
  }'

# 2. Ask for an AI itinerary (trip_id 1, with preferences)
curl -X POST http://127.0.0.1:8000/trips/1/ai-itinerary \
  -H "Content-Type: application/json" \
  -d '{"preferences": "love food, museums, and walking tours; no early mornings"}'
```

The AI endpoint returns JSON like:

```json
{
  "trip_id": 1,
  "destination": "Tokyo, Japan",
  "days": [
    {
      "day": 1,
      "date": "2026-09-01",
      "summary": "Arrival and Shibuya exploration",
      "activities": ["Check into hotel", "Shibuya Crossing", "Dinner in Omoide Yokocho"]
    }
  ]
}
```

## Project structure

```
travel_planner_api/
├── main.py                # FastAPI app & all routes
├── database.py             # SQLAlchemy models (Trip, Item) & DB setup
├── schemas.py               # Pydantic request/response models
├── ai_recommendations.py    # Claude API call for itinerary generation
└── README.md
```

## Notes & next steps

- The AI itinerary endpoint considers items you've already added to a trip
  (e.g. a booked hotel) and works around them.
- To add authentication, multiple travelers, or a budget field, extend the
  `Trip` model in `database.py` and the matching schema in `schemas.py`.
- For production use, swap SQLite for PostgreSQL by changing `DATABASE_URL`
  in `database.py`.
