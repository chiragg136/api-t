import datetime as dt
from typing import Optional, List
from pydantic import BaseModel, ConfigDict


# ---------- Item Schemas ----------

class ItemBase(BaseModel):
    title: str
    category: Optional[str] = None
    date: Optional[dt.date] = None
    time: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None


class ItemCreate(ItemBase):
    pass


class ItemUpdate(BaseModel):
    title: Optional[str] = None
    category: Optional[str] = None
    date: Optional[dt.date] = None
    time: Optional[str] = None
    location: Optional[str] = None
    notes: Optional[str] = None


class ItemOut(ItemBase):
    model_config = ConfigDict(from_attributes=True)
    id: int
    trip_id: int


# ---------- Trip Schemas ----------

class TripBase(BaseModel):
    name: str
    destination: str
    start_date: dt.date
    end_date: dt.date
    notes: Optional[str] = None


class TripCreate(TripBase):
    pass


class TripUpdate(BaseModel):
    name: Optional[str] = None
    destination: Optional[str] = None
    start_date: Optional[dt.date] = None
    end_date: Optional[dt.date] = None
    notes: Optional[str] = None


class TripOut(TripBase):
    model_config = ConfigDict(from_attributes=True)
    id: int


class TripWithItems(TripOut):
    items: List[ItemOut] = []


# ---------- AI Recommendation Schemas ----------

class ItineraryRequest(BaseModel):
    preferences: Optional[str] = None  # e.g. "love food and museums, traveling with kids"


class ItineraryDayPlan(BaseModel):
    day: int
    date: Optional[dt.date] = None
    summary: str
    activities: List[str]


class ItineraryResponse(BaseModel):
    trip_id: int
    destination: str
    days: List[ItineraryDayPlan]
