from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List

import database
import schemas
from ai_recommendations import generate_itinerary

app = FastAPI(title="Travel Planner API", version="1.0.0")

database.init_db()


# ---------------------------------------------------------------------------
# Trips
# ---------------------------------------------------------------------------

@app.post("/trips", response_model=schemas.TripOut)
def create_trip(trip: schemas.TripCreate, db: Session = Depends(database.get_db)):
    db_trip = database.Trip(**trip.model_dump())
    db.add(db_trip)
    db.commit()
    db.refresh(db_trip)
    return db_trip


@app.get("/trips", response_model=List[schemas.TripOut])
def list_trips(db: Session = Depends(database.get_db)):
    return db.query(database.Trip).all()


@app.get("/trips/{trip_id}", response_model=schemas.TripWithItems)
def get_trip(trip_id: int, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    return trip


@app.put("/trips/{trip_id}", response_model=schemas.TripOut)
def update_trip(trip_id: int, updates: schemas.TripUpdate, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    for field, value in updates.model_dump(exclude_unset=True).items():
        setattr(trip, field, value)
    db.commit()
    db.refresh(trip)
    return trip


@app.delete("/trips/{trip_id}")
def delete_trip(trip_id: int, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    db.delete(trip)
    db.commit()
    return {"detail": f"Trip {trip_id} deleted"}


# ---------------------------------------------------------------------------
# Items
# ---------------------------------------------------------------------------

@app.post("/trips/{trip_id}/items", response_model=schemas.ItemOut)
def add_item(trip_id: int, item: schemas.ItemCreate, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    db_item = database.Item(**item.model_dump(), trip_id=trip_id)
    db.add(db_item)
    db.commit()
    db.refresh(db_item)
    return db_item


@app.get("/trips/{trip_id}/items", response_model=List[schemas.ItemOut])
def list_items(trip_id: int, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    return trip.items


@app.put("/items/{item_id}", response_model=schemas.ItemOut)
def update_item(item_id: int, updates: schemas.ItemUpdate, db: Session = Depends(database.get_db)):
    item = db.query(database.Item).filter(database.Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    for field, value in updates.model_dump(exclude_unset=True).items():
        setattr(item, field, value)
    db.commit()
    db.refresh(item)
    return item


@app.delete("/items/{item_id}")
def delete_item(item_id: int, db: Session = Depends(database.get_db)):
    item = db.query(database.Item).filter(database.Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="Item not found")
    db.delete(item)
    db.commit()
    return {"detail": f"Item {item_id} deleted"}


# ---------------------------------------------------------------------------
# AI Recommendations
# ---------------------------------------------------------------------------

@app.post("/trips/{trip_id}/ai-itinerary", response_model=schemas.ItineraryResponse)
def ai_itinerary(trip_id: int, request: schemas.ItineraryRequest, db: Session = Depends(database.get_db)):
    trip = db.query(database.Trip).filter(database.Trip.id == trip_id).first()
    if not trip:
        raise HTTPException(status_code=404, detail="Trip not found")
    try:
        return generate_itinerary(trip, request.preferences)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"AI itinerary generation failed: {e}")


@app.get("/")
def root():
    return {"message": "Travel Planner API is running. Visit /docs for interactive API docs."}
